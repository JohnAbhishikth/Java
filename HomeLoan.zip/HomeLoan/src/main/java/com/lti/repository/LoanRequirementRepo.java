package com.lti.repository;

import java.util.List;

import com.lti.entity.LoanRequirement;

public interface LoanRequirementRepo {

	public List<LoanRequirement> getAllLoanRequirement();						//done
	public LoanRequirement getLoanRequirement(int applicationId);				//done
	public void addLoanRequirement(LoanRequirement loanRequirement, int appId);	//done	

}

/* 	applicationId  	NUMBER(5),
 *	Eligible_Amount	NUMBER(8),					//60*0.6*monthly salary
 *	Required_Amount	NUMBER(8),
 *	Rate_of_Interest	NUMBER(5,3),
 *	Loan_Tenure	NUMBER(3),
 */