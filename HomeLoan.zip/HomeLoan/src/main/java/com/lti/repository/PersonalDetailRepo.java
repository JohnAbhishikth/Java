package com.lti.repository;

import java.util.List; 

import com.lti.entity.PersonalDetail;

public interface PersonalDetailRepo {
	
	void insertPersonalDetail(PersonalDetail personalDetail); //Create	1
	public List<PersonalDetail> getAllPersonalDetails();	//2
	PersonalDetail getPersonalDetailEmail(String emailid); //Read	//3
	List<PersonalDetail> getPersonalDetailAppID(int applicationid);	//4
	void updatePersonalDetailMobile(String emailid, String mobile); //Update	5
	void updatePersonalDetailPassword(String emailid, String password);	//6
	
	
	public PersonalDetail login(String emailId);
		
}


