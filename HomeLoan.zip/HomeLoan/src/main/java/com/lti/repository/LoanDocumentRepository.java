package com.lti.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.entity.LoanDocument;
import com.lti.entity.PropertyDetail;

@Repository
public interface LoanDocumentRepository {
	
//	void insertLoanDocumentRepository(LoanDocument loanDocument );
//	List<LoanDocument> getLoanDocument();
//	LoanDocument getLoanDocument (int applicationId);
//	void updateLoanDocument(LoanDocument loanDocument);
//	void deleteLoanDocument(LoanDocument loanDocument);
	
	public List<LoanDocument> getAllLoanDocument();
	public LoanDocument getLoanDocumentByApplicationId(int applicationId);
	public void insertLoanDocument (LoanDocument loanDocument);
	

}
