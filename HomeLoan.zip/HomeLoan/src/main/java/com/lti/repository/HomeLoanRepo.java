package com.lti.repository;

import com.lti.entity.ApplicationDetail;
import com.lti.entity.EmploymentDetail;
import com.lti.entity.LoanDocument;
import com.lti.entity.LoanRequirement;
import com.lti.entity.PropertyDetail;

public interface HomeLoanRepo {
	
//	public void	insertIntoHomeLoan(ApplicationDetail applicationDetail);	
	
	public void	insertIntoHomeLoanViaAll(ApplicationDetail appDet,
			EmploymentDetail empDetail, LoanRequirement loanReq,
			PropertyDetail propertyDet, LoanDocument loanDoc);
	
//	public void	insertIntoHomeLoanViaAllWithEmail(ApplicationDetail appDet,
//			EmploymentDetail empDetail, LoanRequirement loanReq,
//			PropertyDetail propertyDet, LoanDocument loanDoc, String emailid);
	
//	public List<String> getAllApplication(int appId);
}
