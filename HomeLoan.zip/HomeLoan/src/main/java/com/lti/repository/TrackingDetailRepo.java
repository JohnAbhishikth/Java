package com.lti.repository;

import java.util.List;

import com.lti.entity.TrackingDetail;

public interface TrackingDetailRepo {
	
/*	applicationId 	NUMBER(5),
	Status		varchar2(25),
	Application_Date	date,
	verification_date	date,
	Approved_Date	date,
*/	
	
	public List<TrackingDetail> getAllTrackingDetail();									//done
	public TrackingDetail 		getTrackingDetailByAppId(int applicationId);			//done
	public List<TrackingDetail> getStatusTrackingDetail(String status);					//done
	
	public void updateStatusTrackingDetail(int applicationId, String status);			//done
	public void insertTrackingDetail(TrackingDetail trackingDetail, int applicationId);	//done

	public List<Object> getStatusByEmail(String emailid);
}
