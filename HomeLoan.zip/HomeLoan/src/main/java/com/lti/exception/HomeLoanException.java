package com.lti.exception;

public class HomeLoanException extends RuntimeException{
	
	public HomeLoanException() {
		super();
	}
	public HomeLoanException(String msg) {
		super(msg);	
		//System.out.println(msg);
	}
}