package com.lti.service;

import com.lti.dto.LoanApplicationDto;
import com.lti.dto.StatusDto;

public interface LoanApplicaionService {

	public String addLoanApplication(LoanApplicationDto loanApplicationDto);
	public StatusDto getTrackingDetailByEmail(StatusDto statusDto);
}
