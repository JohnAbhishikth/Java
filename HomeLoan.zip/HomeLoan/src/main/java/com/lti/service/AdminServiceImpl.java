package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.lti.entity.AdminLogin;
import com.lti.exception.HomeLoanException;
import com.lti.repository.AdminLoginRepo;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired private AdminLoginRepo adminLoginRepo;
	
	@Override
	public String adminLogin(String Id, String password) {
		
		//1.wrong Admin		2.Wrong Password	3.Successfull
		
		//	admin   :  ad123
		//	pass	:  ad@123
		
		
		try {
			com.lti.entity.AdminLogin adminLogin = adminLoginRepo.loginAdmin(Id);

			if (adminLogin==null) { //if(adminLogin.getAdminId()==null
				throw new HomeLoanException("Invalid Admin User");

			} else if(!adminLogin.getPassword().equals(password)) {		//5!=4			
				throw new HomeLoanException("Wrong Password");
				
				}else {
					return "Login Sucessful";
				}
		}
		catch (HomeLoanException e) {
			throw e;
		}
	}

}
