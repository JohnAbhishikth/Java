package com.lti.service;

import java.util.List;

import com.lti.dto.StatusDto;
import com.lti.entity.TrackingDetail;

public interface TrackingDetailService {
	
	
	public List<TrackingDetail> getAllTrackingDetail();		
	public StatusDto 		getTrackingDetailByAppId(int applicationId);		//done			
	public List<TrackingDetail> getStatusTrackingDetail(String status);					
	public void updateStatusTrackingDetail(int applicationId, String status);			//done	
	
	public void insertTrackingDetail(TrackingDetail trackingDetail, int applicationId);	
	public List<StatusDto> getStatusTrackingDetail(StatusDto statusDto);
}
