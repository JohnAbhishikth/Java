package com.lti.service;

import com.lti.dto.SanctionDto;

public interface SanctionedDetailService {

	public SanctionDto getSanctionedDetailByAccNo(int accountNo);
}
