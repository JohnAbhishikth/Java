package com.lti.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dto.StatusDto;
import com.lti.entity.ApplicationDetail;
import com.lti.entity.PersonalDetail;
import com.lti.entity.TrackingDetail;
import com.lti.exception.HomeLoanException;
import com.lti.repository.ApplicationDetailRepo;
import com.lti.repository.TrackingDetailRepo;

@Service
public class TrackingDetailServiceImpl implements TrackingDetailService {

	@Autowired
	private TrackingDetailRepo trackingDetailRepo;
	@Autowired
	private ApplicationDetailRepo applicationRepo;
	
	@Override
	public List<TrackingDetail> getAllTrackingDetail() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatusDto getTrackingDetailByAppId(int applicationId) {
		try {
			StatusDto loanStatusDto = new StatusDto();
			TrackingDetail trackingDetail =  trackingDetailRepo.getTrackingDetailByAppId(applicationId);
			
			loanStatusDto.setApplicationDate(trackingDetail.getApplicationDate());
			loanStatusDto.setapplicationid(trackingDetail.getApplicationid());
			loanStatusDto.setStatus(trackingDetail.getStatus());
			
			return loanStatusDto;	
		} catch (Exception e) {
			throw new RuntimeException("Application Details Not Available");
			}
	}

	@Override
	public List<TrackingDetail> getStatusTrackingDetail(String status) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void insertTrackingDetail(TrackingDetail trackingDetail, int applicationId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateStatusTrackingDetail(int applicationId, String status) {
		try {
			TrackingDetail trackingDetail = trackingDetailRepo.getTrackingDetailByAppId(applicationId);
			if (trackingDetail==null) {
				throw new HomeLoanException("Invalid User");
			}
			else {
				trackingDetailRepo.updateStatusTrackingDetail(applicationId, status);
				}
		} catch (HomeLoanException e) {
			throw e;
		}
		
	}


	@Override
	public List<StatusDto> getStatusTrackingDetail(StatusDto statusDto) {
		// TODO Auto-generated method stub
		try {
			List<StatusDto> StatusDtoList = new ArrayList<StatusDto>();
			
			List<TrackingDetail> trackingDetail =  trackingDetailRepo.getStatusTrackingDetail(statusDto.getStatus());
			System.out.println("=======>Tracking"+trackingDetail);
			for (TrackingDetail trackingDetail2 : trackingDetail) {
				if(trackingDetail==null) {
					continue;
				}else {

				ApplicationDetail applicationDetail = applicationRepo.getApplicationDetailByAppId(trackingDetail2.getApplicationid());
				PersonalDetail personalDetail = applicationDetail.getPersonalDetail();
				System.out.println("======>"+trackingDetail2.getApplicationid());
				StatusDto loanStatusDto = new StatusDto();
				loanStatusDto.setEmailid(personalDetail.getEmailid());
				loanStatusDto.setApplicationDate(trackingDetail2.getApplicationDate());
				loanStatusDto.setapplicationid(trackingDetail2.getApplicationid());
				loanStatusDto.setStatus(trackingDetail2.getStatus());
				
				loanStatusDto.setFname(personalDetail.getFname());
				loanStatusDto.setLname(personalDetail.getLname());
				
				StatusDtoList.add(loanStatusDto);
				
			}
		}	
		return StatusDtoList;	
					
		} catch (Exception e) {
			throw new RuntimeException("Application Details Not Available");
			}

	}


}
